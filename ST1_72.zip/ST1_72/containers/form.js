// Express is a minimal and flexible Node.js web application framework that provides a robust
// set of features to develop web and mobile applications. 
// It facilitates the rapid development of Node based Web applications

const express = require('express');

// module to handle get request on localhost:3000 and load the registration form
exports.form = (req, res) =>
{  
    res.sendFile('public/form.html', { root: '.' })
}  

// module to handle post request on localhost:3000 when user submits the registration form
// form data is captured and sent back as a response
exports.formprocess = (req, res) =>
{  

    const total = parseInt(req.body.maths) + parseInt(req.body.physics) + parseInt(req.body.chemistry) + parseInt(req.body.english) + parseInt(req.body.pa);
    const avg = total/5;
    let grade = 'X';
    if(avg>=90){
        grade = 'A';
    }else if(avg>=80){
        grade = 'B';
    }else if(avg>=60){
        grade = 'C';
    }else if(avg>=50){
        grade = 'D';
    }else if(avg>=33){
        grade = 'E';
    }else{
        grade = 'F';
    }

   console.log(req.body);
   res.write('<h1> Your Score Card </h1>');
   res.write('<p> Name : '+ req.body.name + '</p>');
   res.write('<p> ID : '+ req.body.id + '</p>');
   res.write('<p> Address : '+ req.body.address + '</p>');
   res.write('<p> Maths Score : '+ req.body.maths + '</p>');
   res.write('<p> Physics Score : '+ req.body.physics + '</p>');
   res.write('<p> Chemistry Score : '+ req.body.chemistry + '</p>');
   res.write('<p> English Score : '+ req.body.english + '</p>');
   res.write('<p> PA Score : '+ req.body.pa + '</p>');
   res.write('<br>');
   res.write('<br>');
   res.write('<p> Total Score : '+ total + '</p>');
   res.write('<p> Average Score : '+ avg + '</p>');
   res.write('<p> Grade : '+ grade + '</p>');
   res.end();
}  

// res.send is equivalent to res.write + res.end. key difference is
// res.send can be called only once where as res.write can be called multiple times followed by a res.end. 
// res.end is necessary or else browser will keep on waiting for response